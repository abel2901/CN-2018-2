from __future__ import division
import numpy as np
import math as m
import matplotlib.pyplot as plt
iterations = 60

from cos_sen_taylor import *

#função principal
def michalewicz(x):
	return sine(x)*sine((np.power(x, 2))/np.pi)

#derivada

def michalewiczdx(x):
	return sine((np.power(x, 2))/np.pi)*cosine(x)+((2*x)*(sine(x)*cosine((np.power(x, 2))/np.pi)))/np.pi

#função de iteracao
def michalewicziterative(x):
	return x + ((sine(x)*sine((np.power(x, 2)/np.pi)))/np.power(2, x))

#gera o gráfico da função (a decidir por parâmetro)
def graphic(fn):
	x = []
	y = []
	i = -6.0
	while(i<=6.0):
		x.append(i)
		y.append(fn(i))
		i = i+0.01

	fig, ax = plt.subplots()
	ax.plot(x, y)

	ax.set(xlabel='x', ylabel='f(x)',
			title='Função de Michalewicz')
	ax.grid()

	#fig.savefig("michalewicz.png")
	plt.show()
