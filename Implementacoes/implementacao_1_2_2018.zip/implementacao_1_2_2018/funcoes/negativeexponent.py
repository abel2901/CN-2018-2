from __future__ import division
import numpy as np
import math as m
import matplotlib.pyplot as plt

#função principal
def negativeexponent(x):
	return (np.power(x, 3) - (3*np.power(x, 2))*(np.power(2, (-x)))
			+ 3*x*(np.power(4, (-x))) - (np.power(8, (-x))))

#derivada
def negativeexponentdx(x):
	return ((np.power(8, x)*(np.power(4, x)*(3*np.power(x, 2)*np.power(2, x) -
			6*x + 3*np.power(x, 2)*np.log(2)) + np.power(2, x)*(3 -
			3*x*np.log(4))) + np.power(2, x)*np.power(4, x)*np.log(8))/
			(np.power(2, x)*np.power(4, x)*np.power(8, x)))

#função de iteracao
def negativeexponentiterative(x):
	return x - negativeexponent(x)*np.power(x, -9)

#gera o gráfico da função (a ser definida por parâmetro)
def graphic(fn):
	x = np.arange(-0.5, 2.0, 0.001)
	y = fn(x)

	fig, ax = plt.subplots()
	ax.plot(x, y)

	ax.set(xlabel='x', ylabel='f(x)',
			title='Expoente Negativo')
	ax.grid()

	#fig.savefig("negexponential.png")
	plt.show()