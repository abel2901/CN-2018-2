from __future__ import division
import numpy as np
import math as m
import matplotlib.pyplot as plt
iterations = 50

from cos_sen_taylor import *

#função principal
def cosineplusone(x):
	return cosine(x) + 1

#derivada da função
def cosineplusonedx(x):
	return sine(x)*(-1)

#função de iteração
def cosineplusoneiterative(x):
    return x - 3*x*(cosine(x) + 1)

#plotagem do gráfico das funções (parâmetro definido na chamada)
def graphic(fn):
	x = []
	y = []
	i = -20.0
	while(i <= 20.0):
		y.append(fn(i))
		x.append(i)
		i = i+0.1

	fig, ax = plt.subplots()
	ax.plot(x, y)

	ax.set(xlabel='x', ylabel='f(x)',
			title='Cos / Sen')
	ax.grid()

	#fig.savefig("cosineplusone.png")
	plt.show()
