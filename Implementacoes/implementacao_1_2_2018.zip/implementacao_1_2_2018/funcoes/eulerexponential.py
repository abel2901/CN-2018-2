from __future__ import division
import numpy as np
import matplotlib.pyplot as plt

#função principal
def eulerexponential(x):
	exp = np.power((x-2), 2)
	return (x-1)*(np.power(np.e, exp)) - 1

#funções iterativas
#g1(x):
def eulerexponentialiterative1(x):
	exp = np.power((x-2), 2)
	euler = np.power(np.e, exp)
	xbar = (1 + euler)/euler
	return xbar

#g2(x):
def eulerexponentialiterative2(x):
	xsqrt = (-1)*np.log(x-1) + 4*x - 4
	xbar = np.sqrt(xsqrt)
	return xbar

#g3(x):
def eulerexponentialiterative3(x):
	euler1 = np.power(np.e, (np.power(x, 2) + 4))
	euler2 = np.power(np.e, 4*x)
	xsqrt = np.log(euler2 + euler1) - np.log(x) - 4
	xbar = np.sqrt(xsqrt)
	return xbar

#função para plotar o gráfico da função
def graphic(fn):
	x = np.arange(1.5, 2.5, 0.0001)
	y = fn(x)

	fig, ax = plt.subplots()
	ax.plot(x, y)

	ax.set(xlabel='x', ylabel='f(x)',
			title='f(x) = (x-1)*e^((x-2)^2) - 1')

	ax.grid()

	#fig.savefig("/home/progdeb/Documentos/anderson_vieira/main/questao2/graficos/eulerexponential.png")
	plt.show()