from __future__ import division
import numpy as np
import math as m
import matplotlib.pyplot as plt

#função principal
def quintexp(x):
	return np.power((x - 1.44), 5)

#derivada
def quintexpdx(x):
	return 5*np.power((x - 1.44), 4)

#função de iteracao
def quintexpiterative(x):
	return x - quintexp(x)*np.power(x, 28)

#gera o gráfico da função (a ser definida por parâmetro)
def graphic(fn):
	x = np.arange(0, 3, 0.00001)
	y = fn(x)

	fig, ax = plt.subplots()
	ax.plot(x, y)

	ax.set(xlabel='x', ylabel='f(x)',
			title='Quinta potência')
	ax.grid()

	#fig.savefig("quintexp.png")
	plt.show()