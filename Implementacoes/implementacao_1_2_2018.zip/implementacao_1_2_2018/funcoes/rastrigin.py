from __future__ import division
import numpy as np
import matplotlib.pyplot as plt

from cos_sen_taylor import *

#função principal
def rastrigin(x):
	return 10 + np.power((x - 2), 2) - 10*cosine(2*np.pi*x)

#derivada
def rastrigindx(x):
	return -4 + 2*x +20*np.pi*sine(2*np.pi*x)

#função de iteração
def rastriginiterative(x):
	#return x + (np.power(x, 2) + 14 - 10*cosine(2*np.pi*x))/np.power(x, 20)
	return x - (np.power((x + 3), -3) + np.power(((9*x) + 13), -2))*rastrigin(x)

#gera o gráfico da função (a ser definida por parâmetro)
def graphic(fn):
	x = []
	y = []
	i = -2.0
	while(i <= 8.0):
		x.append(i)
		y.append(fn(i))
		i = i+0.001

	fig, ax = plt.subplots()
	ax.plot(x, y)

	ax.set(xlabel='x', ylabel='f(x)',
			title='Função de Rastrigin')
	ax.grid()

	#fig.savefig("rastrigin.png")
	plt.show()