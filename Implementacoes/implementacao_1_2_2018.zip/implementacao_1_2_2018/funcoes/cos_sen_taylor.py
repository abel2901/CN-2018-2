#Arquivo para funções básicas
from __future__ import division
import numpy as np
import math as m
import matplotlib.pyplot as plt
iterations = 50

#função cosseno por série de taylor
def cosine(x):
	if(abs(x) > 2*np.pi):
		sign=1;
		if(x < 0.0):
			sign = sign*(-1)

		s = abs(x)
		while(s > 0.0):
			s = (s - 2*np.pi)

		s = (s + 2*np.pi)*sign
		x = s

	cos = (m.pow(x, 0))
	for i in range(1, iterations):
		taylor = (((m.pow(x, 2*i))/(m.factorial(2*i)))*m.pow((-1), i))
		cos = cos + taylor
	return cos

#função seno por série de taylor
def sine(x):
	if(abs(x) > 2*np.pi):
		sign = 1
		if(x < 0.0):
			sign = sign*(-1)

		s = abs(x)
		while(s > 0.0):
			s = (s - 2*np.pi)

		s = (s + (2*np.pi))*sign
		x = s

	sen = np.power(x, 1)
	for i in range(1, iterations):
		taylor = ((np.power(x, ((2*i)+1))/(m.factorial((2*i)+1)))*(np.power((-1), i)))
		sen = sen + taylor

	return sen