#Cabeçalho padrão para todos os métodos
#bibliotecas para operações matemáticas
from __future__ import division
import numpy as np
import matplotlib.pyplot as plt

#bibliotecas para operacoes com arquivos
import sys, os
sys.path.append(os.path.abspath(os.path.join('..', '..', 'funcoes')))

#funcoes:
#f1(x):
from cosineplusone import *
#f2(x):
from rastrigin import *
#f3(x):
from negativeexponent import *
#f4(x):
from michalewicz import *
#f5(x):
from quintexp import *

#constantes necessárias:
#precisão solicitada
eps = 0.000001
#numero máximo de iterações
iterations = 1000
#função para determinar o erro relativo
def ER(x, root):
    return abs(root - x)/abs(x)

#fim do cabeçalho

#implementacao do metodo

def secante(x0, x1, fn, root):
	initx0 = x0
	initx1 = x1
	if(abs(fn(x0)) < eps):
		print("x0 = " + str(x0) + ", x1 = " + str(x1) + ", x̄ = " + str(x0) + ", " + str(fn(x0)) + ", " +
				str(ER(x0, root)) + ", 0")
		return

	if(abs(fn(x1)) < eps or abs(x1-x0) < eps):
		print("x0 = " + str(x0) + ", x1 = " + str(x1) + ", x̄ = " + str(x1) + ", " + str(fn(x1)) + ", " +
				str(ER(x1, root)) + ", 0")
		return

	x = []
	for k in range(iterations):
		x.append(x1 - (fn(x1)*(x1 - x0))/(fn(x1) - fn(x0)))

		if(abs(fn(x[k])) < eps and abs(x[k] - x1) < eps):
			print("x0 = " + str(initx0) + ", x1 = " + str(initx1) + ", x̄ = " + str(x[k]) + ", " + str(fn(x[k])) + ", " +
				str(ER(x[k], root)) + ", " + str(k+1))
			return

		x0 = x1
		x1 = x[k]

	if(k == iterations-1):
		print("x0 = " + str(initx0) + ", x1 = " + str(initx1) + ", x̄ = - , " + "-" + ", - , " + str(k+1))
		return

#fim da implementacao

#função comum a todos metodos (a ser chamada na main)
def execute():
	secante(2.0, 3.0, cosineplusone, np.pi)
	secante(1.4, 1.6, rastrigin, 2.0)
	secante(0.3, 0.4, negativeexponent, 0.6411833763122559)
	secante(2.3, 2.7, michalewicz, np.pi)
	secante(1.0, 1.2, quintexp, 1.44)