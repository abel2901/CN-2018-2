#Cabeçalho padrão para todos os métodos
#bibliotecas para operações matemáticas
from __future__ import division
import numpy as np
import matplotlib.pyplot as plt

#bibliotecas para operacoes com arquivos
import sys, os
sys.path.append(os.path.abspath(os.path.join('..', '..', 'funcoes')))

#funcoes:
#f1(x):
from cosineplusone import *
#f2(x):
from rastrigin import *
#f3(x):
from negativeexponent import *
#f4(x):
from michalewicz import *
#f5(x):
from quintexp import *

#constantes necessárias:
#precisão solicitada
eps = 0.000001
#numero máximo de iterações
iterations = 10000
#função para determinar o erro relativo
def ER(x, root):
    return abs(root - x)/abs(x)

#fim do cabeçalho

#implementacao do metodo

#definição para gerar gráficos de erro relativo
#def fixed_point(x0, fn, phi, root, d):
def fixed_point(x0, fn, phi, root):
	x = []
	x.append(x0)
	#(insere elementos do domínio para os gráficos da questão 2)d.append(x0)
	if(abs(fn(x[0])) < eps):
		print("x0 = " + str(x0) + ", x̄ = " + str(x0) + ", " + str(fn(x[0])) + ", " +
				str(ER(x[0], root)) + ", 0")
		return
	
	for k in range(1, iterations):
		x.append(phi(x[k-1]))
		#(insere elementos do domínio para os gráficos da questão 2)d.append(x[k])

		if(abs(fn(x[k])) < eps and abs(x[k] - x[k-1]) < eps ):
			print("x0 = " + str(x[0]) + ", x̄ = " + str(x[k]) + ", " + str(fn(x[k])) + ", " +
					str(ER(x[k], root)) + ", " + str(k+1))
			return

	if(k == iterations-1):
		print("x0 = " + str(x[0]) + ", x̄ = - , " + "-" + ", - , " + str(k+1))
		return

#fim da implementacao

#função comum a todos metodos (a ser chamada na main)
def execute():
	fixed_point(2.0, cosineplusone, cosineplusoneiterative, np.pi)
	fixed_point(2.5, rastrigin, rastriginiterative, 2.0)
	fixed_point(1.3, negativeexponent, negativeexponentiterative, 0.6411833763122559)
	fixed_point(3.0, michalewicz, michalewicziterative, np.pi)
	fixed_point(1.0, quintexp, quintexpiterative, 1.44)