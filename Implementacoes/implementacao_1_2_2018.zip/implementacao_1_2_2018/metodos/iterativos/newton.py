#Cabeçalho padrão para todos os métodos
#bibliotecas para operações matemáticas
from __future__ import division
import numpy as np
import matplotlib.pyplot as plt

#bibliotecas para operacoes com arquivos
import sys, os
sys.path.append(os.path.abspath(os.path.join('..', '..', 'funcoes')))

#funcoes:
#f1(x):
from cosineplusone import *
#f2(x):
from rastrigin import *
#f3(x):
from negativeexponent import *
#f4(x):
from michalewicz import *
#f5(x):
from quintexp import *

#constantes necessárias:
#precisão solicitada
eps = 0.000001
#numero máximo de iterações
iterations = 1000
#função para determinar o erro relativo
def ER(x, root):
    return abs(root - x)/abs(x)

#fim do cabeçalho

#implementacao do metodo

def newton(x0, fn, dv, root):
	x = []
	#inicializa lista com o x fornecido
	x.append(x0)
	#se já for a raiz, retorna o valor inicial
	if(abs(fn(x[0])) < eps):
		print("x0 = " + str(x0) + ", x̄ = " + str(x0) + ", " + str(fn(x[0])) + ", " +
				str(ER(x0, root)) + ", 0")
		return

	#inicia processo iterativo
	for k in range(1, iterations):
		#utiliza a funcao de iteracao fornecida(derivada)
		x.append(x[k-1] - (fn(x[k-1])/(dv(x[k-1]))))

		#se o valor atual da lista atender a condicao, retorna-o
		if(abs(fn(x[k])) < eps and abs(x[k] - x[k-1]) < eps):
			print("x0 = " + str(x[0]) + ", x̄ = " + str(x[k]) + ", " + str(fn(x[k])) + ", " +
					str(ER(x[k], root)) + ", " + str(k+1))
			return

	#alternativa em caso de insucesso
	if(k == iterations-1):
		print("x0 = " + str(x[0]) + ", x̄ = - , " + "-" + ", - , " + str(k+1))
		return
		
#fim da implementacao

#função comum a todos metodos (a ser chamada na main)
def execute():
	newton(2.0, cosineplusone, cosineplusonedx, np.pi)
	newton(1.6, rastrigin, rastrigindx, 2.0)
	newton(0.2, negativeexponent, negativeexponentdx, 0.6411833763122559)
	newton(3.0, michalewicz, michalewiczdx, np.pi)
	newton(0.5, quintexp, quintexpdx, 1.44)