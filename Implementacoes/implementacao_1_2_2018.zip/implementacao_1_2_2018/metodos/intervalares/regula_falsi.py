#Cabeçalho padrão para todos os métodos
#bibliotecas para operações matemáticas
from __future__ import division
import numpy as np
import matplotlib.pyplot as plt

#bibliotecas para operacoes com arquivos
import sys, os
sys.path.append(os.path.abspath(os.path.join('..', '..', 'funcoes')))

#funcoes:
#f1(x):
from cosineplusone import *
#f2(x):
from rastrigin import *
#f3(x):
from negativeexponent import *
#f4(x):
from michalewicz import *
#f5(x):
from quintexp import *

#constantes necessárias:
#precisão solicitada
eps = 0.000001
#numero máximo de iterações
iterations = 15000
#função para determinar o erro relativo
def ER(x, root):
    return abs(root - x)/abs(x)

#fim do cabeçalho

#implementacao do metodo

def regula_falsi(a, b, fn, root):
    inita = a
    initb = b
    if(abs(b-a) < eps and fn(b)*fn(a) < 0):
        print("a = " + str(inita) + ", b = " + str(initb) + 
                ", x̄ = " + str(((b-a)/2 + a)) + ", " + str(fn(((b-a)/2 + a))) + ", " + str(ER(x, root)) + "0")
        return
    
    for k in range(iterations):
        m = fn(a)
        x = (a*fn(b) - b*fn(a))/(fn(b) - fn(a))
        
        if(abs(fn(x)) < eps and fn(b)*fn(a) < 0):
            print("a = " + str(inita) + ", b = " + str(initb) + 
                ", x̄ = " + str(x) + ", " + str(fn(x)) + ", " + str(ER(x, root)) + ", " + str(k+1))
            return
        
        if(m*fn(x) > 0):
            a = x
        else:
            b = x
            
        if(abs(b-a) < eps and fn(b)*fn(a) < 0):
            print("a = " + str(inita) + ", b = " + str(initb) + 
                    ", x̄ = " + str(((b-a)/2 + a)) + ", " + str(fn(((b-a)/2 + a))) + ", " + str(ER(((b-a)/2 + a), root)) + ", " + str(k+1))
            return
        
    if(k == iterations-1):
        print("a = " + str(inita) + ", b = " + str(initb) + 
                ", x̄ = - , " + "-" + ", - , " + str(k+1))
        return

#fim da implementacao

#função comum a todos metodos (a ser chamada na main)
def execute():
	regula_falsi(2.0, 4.0, cosineplusone, np.pi)
	regula_falsi(1.0, 6.0, rastrigin, 2.0)
	regula_falsi(0.3, 2.0, negativeexponent, 0.6411833763122559)
	regula_falsi(2.2, 3.8, michalewicz, np.pi)
	regula_falsi(1.0, 2.0, quintexp, 1.44)