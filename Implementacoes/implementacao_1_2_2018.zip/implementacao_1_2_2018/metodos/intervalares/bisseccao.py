#Cabeçalho padrão para todos os métodos
#bibliotecas para operações matemáticas
from __future__ import division
import numpy as np
import matplotlib.pyplot as plt

#bibliotecas para operacoes com arquivos
import sys, os
sys.path.append(os.path.abspath(os.path.join('..', '..', 'funcoes')))

#funcoes:
#f1(x):
from cosineplusone import *
#f2(x):
from rastrigin import *
#f3(x):
from negativeexponent import *
#f4(x):
from michalewicz import *
#f5(x):
from quintexp import *

#constantes necessárias:
#precisão solicitada
eps = 0.000001
#numero máximo de iterações
iterations = 1000
#função para determinar o erro relativo
def ER(x, root):
	return abs(root - x)/abs(x)

#fim do cabeçalho

#implementacao do metodo

#definição para gerar gráficos de erro relativo
#def bisseccao(a, b, fn, name, d):
def bisseccao(a, b, fn, root):
	inita = a
	initb = b
	#primeira verificacao
	x = (b-a)/2 + a
	#Insere x no domínio da função do gráfico de erro relativod.append(x)
	#se já estiver no intervalo com a precisão desejada
	if((abs(b-a) < eps) and (fn(a)*fn(b) < 0)):
		print("a = " + str(inita) + ", b = " + str(initb) + 
				", x̄ = " + str(((b-a)/2 + a) + ", " + str(fn(x)) + ", " + str(ER(x, root)) + "0"))
		return
	#caso contrário o método é iniciado
	else:
		for k in range(1, iterations):
			#calcula o valor para o k-ésimo a
			ak = fn(a)
			#corte no intervalo
			x = (b-a)/2 + a
			#Insere x no domínio da função do gráfico de erro relativod.append(x)
			#testa condicoes para a bisseccao
			if(ak*fn(x) > 0):
				a = x
			else:
				b = x

			#verifica novamente a precisao da resposta
			if(abs(b-a) < eps and (fn(a)*fn(b) < 0)):
				print("a = " + str(inita) + ", b = " + str(initb) + 
						", x̄ = " + str(((b-a)/2 + a)) + ", " + str(fn(((b-a)/2 + a))) + ", " + str(ER(x, root)) + ", " + str(k+1))
				return
	if(k == iterations-1):
		print("a = " + str(inita) + ", b = " + str(initb) + 
				", x̄ = - , " + " - " + ", - , " + str(k+1))
	return

def execute():
	bisseccao(1.0, 6.0, cosineplusone, np.pi)
	bisseccao(1.0, 3.0, rastrigin, 2.0)
	bisseccao(-1.0, 1.0, negativeexponent, 0.6411833763122559)
	bisseccao(2.0, 4.0, michalewicz, np.pi)
	bisseccao(1.0, 2.0, quintexp, 1.44)
