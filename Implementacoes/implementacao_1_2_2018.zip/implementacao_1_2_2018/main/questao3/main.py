from __future__ import division
import numpy as np
import matplotlib.pyplot as plt

import sys, os
sys.path.append(os.path.abspath(os.path.join('..', '..', 'metodos', 'intervalares')))
sys.path.append(os.path.abspath(os.path.join('..', '..', 'funcoes')))

#Importando função
from eulerexponential import *

#Importando método
from bisseccao import *

#domínio para o gráfico de erro relativo
dom = []

def ER(x):
	return abs(2.0 - x)/abs(x)

def ERgraph(dom):
	x = []
	y = []

	for i in range(len(dom)):
		x.append(i)
		y.append(ER(dom[i]))

	fig, ax = plt.subplots()
	ax.plot(x, y)
	ax.set(xlabel='x', ylabel='y',
			title='Gráfico de Erro Relativo - Método da Bissecção')

	ax.grid()
	fig.savefig("/home/progdeb/Documentos/anderson_vieira/main/questao3/graficos/errorelativo.png")

	plt.show()

#Chamada para análise e gráfico
#bisseccao(1.5, 2.9, eulerexponential, "f(x)", dom)
#Chamada para análise
bisseccao(1.5, 2.9, eulerexponential, 2.0)

#Chamada para o gráfico
#ERgraph(dom)