from __future__ import division
import numpy as np
import matplotlib.pyplot as plt

import sys, os
sys.path.append(os.path.abspath(os.path.join('..', '..', 'metodos', 'iterativos')))
sys.path.append(os.path.abspath(os.path.join('..', '..', 'funcoes')))

from eulerexponential import *
from ponto_fixo import fixed_point

#domínios para os gráficos de erros relativos
#dom1 = []
#dom2 = []
#dom3 = []

#função para os erros relativos
def ER(x):
	return abs(2.0 - x)/abs(x)

#Gera gráfico de erros relativos
def ERgraph(dom1, dom2, dom3):
	x1 = []
	x2 = []
	x3 = []
	y1 = []
	y2 = []
	y3 = []
	for i in range(len(dom1)):
		y1.append(ER(dom1[i]))
		x1.append(i)

	for i in range(len(dom2)):
		y2.append(ER(dom2[i]))
		x2.append(i)

	for i in range(len(dom3)):
		y3.append(ER(dom3[i]))
		x3.append(i)

	fig, ax = plt.subplots()
	ax.plot(x1, y1, label='g1(x)')
	ax.plot(x2, y2, label='g2(x)')
	ax.plot(x3, y3, label='g3(x)')

	ax.set(xlabel='x', ylabel='f(x)',
			title='Gráfico de Erro Relativo - Comparativo')

	ax.legend()
	fig.savefig("/home/progdeb/Documentos/calculo_numerico/implementacoes_1/main/questao2/graficos/errorelativo.png")
	plt.show()

print("Dados para análise")
print("\nResultados da função de iteração 1:")
#chamada para análise e grafico
#fixed_point(4.0, eulerexponential, eulerexponentialiterative1, 2.0, dom1)
#chamada para análise
fixed_point(4.0, eulerexponential, eulerexponentialiterative1, 2.0)
print("\nResultados da função de iteração 2:")
#chamada para análise e gráfico
#fixed_point(4.0, eulerexponential, eulerexponentialiterative2, 2.0, dom2)
#chamada para análise
fixed_point(4.0, eulerexponential, eulerexponentialiterative2, 2.0)
print("\nResultados da função de iteração 3:")
#chamada para análise e gráfico
#fixed_point(4.0, eulerexponential, eulerexponentialiterative3, 2.0, dom3)
#chamada para análise
fixed_point(4.0, eulerexponential, eulerexponentialiterative3, 2.0)

#Chamada para os gráficos
#ERgraph(dom1, dom2, dom3)