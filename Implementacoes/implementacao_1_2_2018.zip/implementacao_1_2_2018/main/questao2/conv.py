from __future__ import division
from main import *

#Função para computar o valor do limite na última iteração
def convergencia(d):
	return (ER(d[len(d)-1]))/ER(d[len(d)-2])

def derivative1(x):
	return (-2*x + 4)/np.power(np.e, np.power((x-2), 2))

#Computa os valores de x assumidos no método do ponto fixo
dom = []
fixed_point(4.0, eulerexponential, eulerexponentialiterative1, 2.0, dom)

#Imprime o valor de C (C = lim(k->oo) e[k+1]/e[k])
print("C: "+str(convergencia(dom)))
#Imprime o valor da raiz na derivada, o qual deve ser igual a C
print("|g'(ξ)|: " + str(abs(derivative1(2.0))))