from __future__ import division
import numpy as np
import matplotlib.pyplot as plt

#Importando os módulos com os métodos
import sys, os
sys.path.append(os.path.abspath(os.path.join('..', '..', 'metodos', 'intervalares')))
sys.path.append(os.path.abspath(os.path.join('..', '..', 'metodos', 'iterativos')))

#Importando as funções que executam os métodos
from bisseccao import execute as execbiss
from regula_falsi import execute as execregfs
from ponto_fixo import execute as execfixpt
from newton import execute as execnew
from secante import execute as execsec

#Executa os métodos para cada função da questão
print("Bisseccao para todas:")
execbiss()
print("\nRegula Falsi para todas:")
execregfs()
print("\nPonto fixo para todas:")
execfixpt()
print("\nNewton para todas:")
execnew()
print("\nSecante para todas:")
execsec()